from portfolio_agent.notifier import push

def record_user_details(email, name="", notes=""):
    text = "Recording new interaction:\n"
    if email:
        text += f"Email: {email}\n"
    if name:
        text += f"Name: {name}\n"
    if notes:
        text += f"Notes: {notes}\n"
    push(text)
    return {"recorded": "ok"}

def record_unknown_question(question):
    push(f"Recording new question: {question}")
    return {"recorded": "ok"}

record_user_details_json = {
    "name": "record_user_details",
    "description": "Use this tool to record that a user is interested in being in touch and provided an email address",
    "parameters": {
        "type": "object",
        "properties": {
            "email": {"type": "string", "description": "The email address of this user"},
            "name": {"type": "string", "description": "The user's name, if they provided it"},
            "notes": {"type": "string", "description": "Any additional information about the conversation that's worth recording to give context"}
        },
        "required": ["email"],
        "additionalProperties": False
    }
}

record_unknown_question_json = {
    "name": "record_unknown_question",
    "description": "Always use this tool to record any question that couldn't be answered as you didn't know the answer",
    "parameters": {
        "type": "object",
        "properties": {
            "question": {"type": "string", "description": "The question that couldn't be answered"}
        },
        "required": ["question"],
        "additionalProperties": False
    }
}