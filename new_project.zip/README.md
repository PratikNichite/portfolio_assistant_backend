---
title: portfolio_assistant
app_file: app.py
sdk: gradio
sdk_version: 5.39.0
---
