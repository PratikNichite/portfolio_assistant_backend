import gradio as gr
from portfolio_agent.agent import PortfolioAssistant

if __name__ == "__main__":
    me = PortfolioAssistant()

    demo = gr.ChatInterface(
        fn=me.chat,
        examples=[
            "What projects has Pratik worked on?",
            "What are Pratik's key skills?",
            "How can I contact Pratik?"
        ]
    )

    demo.launch()